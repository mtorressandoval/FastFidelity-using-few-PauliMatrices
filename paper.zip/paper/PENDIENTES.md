# Pendientes del manuscrito

## Marcadores
- Agradecimientos: `XX` (no se inventan financiaciones).

## Referencias a confirmar en la versión publicada
- Ferrie, *Self-guided quantum tomography*: verificado arXiv:1406.4101; la referencia de revista
  (Phys. Rev. Lett. 113, 190404 (2014)) es de memoria y conviene confirmarla.
- Chen et al. (arXiv:2408.06967): publicado en STOC'25 (p. 429 según arXiv:2607.15559); falta el DOI ACM.
- Grewal et al. (arXiv:2304.13915), García et al. (arXiv:1711.07848), Aaronson et al.
  (arXiv:2211.00747): citados por arXiv; revisar si hay versión de revista.

## Títulos propuestos
1. Self-guided estimation of the stabilizer fidelity with single-copy Pauli measurements (en uso).
2. Estimation of the stabilizer fidelity via direct fidelity estimation and a Pauli store.
3. Stabilizer fidelity of unknown states from single-copy Pauli measurements.
Recomendado: el 1, porque nombra el método y la ventaja experimental.

## Revisión 2
- Simulaciones nuevas (sim1, sim2); Figs. 5 y 6 eliminadas; Figs. 2 y 3 a doble columna.
- Apéndices: demostraciones ampliadas, almacén con ecuaciones, transformada de Walsh (App. C).
- Las cifras de la primera ronda citadas en el texto (arranque a 3 pasos; N = 4000 con n = 8;
  estudio de parámetros) están en `results/archive/`.

## Origen de cada número
Todos los números del texto están en `results/summary.txt`, que genera
`experiments/make_figures.py` a partir de los CSV de `results/`.

## Referencias nuevas (perfil v2)
- MunozMoller2022 (VDGE, arXiv:2110.03709): confirmar volumen y página (Phys. Rev. Appl. 18, 024048).
- Zambrano2023 (iVDGE, arXiv:2304.13388): confirmar si ya está publicado y en qué revista.
- McClean2018, Cerezo2021BP, Cerezo2021VQA, Preskill2018: datos estándar, revisar al final.

## Citas de resultados previos en los apéndices
- Garcia2013 (arXiv:1210.6646): comprobar si se publicó (número exacto de vecinos, Teorema 16).
- Grewal2023: se cita solo como el régimen polinómico con el umbral cos²(π/8) para estados puros;
  confirmar si enuncian explícitamente la unicidad del estado estabilizador más cercano.
- Cochran1977, Goldreich1989, Kushilevitz1993: referencias estándar, revisar formato.
